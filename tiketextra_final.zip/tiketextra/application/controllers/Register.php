<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_pengguna');
	}
	public function index()
	{
		$this->load->view('register');
	}
	public function register_cek()
	{
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('jenkel', 'Jenkel', 'required');
		$this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()==false){
			$this->session->set_flashdata('pesan','Semua data harus diisi!!!');
			redirect('register');
		}else{
			$nama 			= $this->input->post('nama');
			$jenkel 		= $this->input->post('jenkel');
			$pekerjaan		= $this->input->post('pekerjaan');
			$alamat 		= $this->input->post('alamat');
			$email 			= $this->input->post('email');
			$password 		= $this->input->post('password');
			$query			= $this->model_pengguna->cek_pengguna($email);
			if($query->num_rows()>0){
				$this->session->set_flashdata('pesan','Email sudah digunakan oleh pengguna lain!!!');
				redirect('register');
			}else{
				$data_pengguna = array(
								'nama'		=> $nama,
								'jenkel'	=> $jenkel,
								'pekerjaan'	=> $pekerjaan,
							   	'alamat'	=> $alamat,
							   	'email'		=> $email,
							   	'password'	=> $password);
				$this->model_pengguna->tambah_pengguna($data_pengguna);
				$this->session->set_flashdata('pesan','Register berhasil silahkan melakukan login!!!');
				redirect('login');
			}
		}
	}
}
