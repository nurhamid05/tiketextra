<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_pengguna');
		$this->load->model('model_login');
	}
	public function index()
	{
		if($this->session->userdata('email')==''){
			redirect('login');
		}else{
			$this->load->view('dashboard');		
		}
	}
	public function login_cek()
	{
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()==false){
			$this->session->set_flashdata('pesan','Email dan Password harus diisi!!!');
			redirect('login');
		}else{
			$email 			= $this->input->post('email');
			$password 		= $this->input->post('password');
			$query			= $this->model_login->cek_login($email,$password);
			$data['login']	= $query->row_array();
			if($query->num_rows()>0){
				$data_sesi = array(
						'nama'		 =>$data['login']['nama'],
						'jenkel'	 =>$data['login']['jenkel'],
						'email'		 =>$data['login']['email'],
						'alamat'	 =>$data['login']['alamat'],
						'id_pengguna'=>$data['login']['id_pengguna'],
						'login'		 =>TRUE);
				$this->session->set_userdata($data_sesi);
				redirect('dashboard',$data);
			}else{
				$this->session->set_flashdata('pesan','Email atau Password anda salah');
				redirect('login');
			}
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
}
