<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_pengguna');
	}
	public function index()
	{
		if($this->session->userdata('email')==''){
			redirect('login');
		}else{
			$data['pengguna'] = $this->model_pengguna->pengguna()->result();
			$this->load->view('pengguna',$data);
		}
	}
	public function edit($id_pengguna)
	{
		if($this->session->userdata('email')==''){
			redirect('login');
		}else{
		$data['pengguna'] 	= $this->model_pengguna->periksa_pengguna($id_pengguna)->row_array();
		$this->load->view('edit_pengguna',$data);
		}
	}
	public function tambah()
	{
		if($this->session->userdata('email')==''){
			redirect('login');
		}else{
		$this->load->view('tambah_pengguna');
		}
	}
	public function proses_tambah()
	{
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('jenkel', 'Jenkel', 'required');
		$this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()==false){
			$this->session->set_flashdata('pesan','Semua data harus diisi!!!');
			redirect('pengguna/tambah');
		}else{
			$nama 			= $this->input->post('nama');
			$jenkel 		= $this->input->post('jenkel');
			$pekerjaan		= $this->input->post('pekerjaan');
			$alamat 		= $this->input->post('alamat');
			$email 			= $this->input->post('email');
			$password 		= $this->input->post('password');
			$query			= $this->model_pengguna->cek_pengguna($email);
			if($query->num_rows()>0){
				$this->session->set_flashdata('pesan','Email sudah digunakan oleh pengguna lain!!!');
				redirect('pengguna/tambah');
			}else{
				$data_pengguna = array(
								'nama'		=> $nama,
								'jenkel'	=> $jenkel,
								'pekerjaan'	=> $pekerjaan,
							   	'alamat'	=> $alamat,
							   	'email'		=> $email,
							   	'password'	=> $password);
				$this->model_pengguna->tambah_pengguna($data_pengguna);
				$this->session->set_flashdata('pesan','Data berhasil ditambah');
				redirect('pengguna');
			}
		}
	}
	public function proses_edit($id_pengguna){
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		if($this->form_validation->run()==false){
			redirect('pengguna/edit/'.$id_pengguna);
		}else{
			$data['pengguna']= $this->model_pengguna->periksa_pengguna($id_pengguna)->row_array();
			$nama 			 = $this->input->post('nama');
			$jenkel 		 = $this->input->post('jenkel');
			$pekerjaan		 = $this->input->post('pekerjaan');
			$alamat 		 = $this->input->post('alamat');
			$email 			 = $this->input->post('email');
			$password		 = $this->input->post('password');
			if($data['pengguna']['email']==$email){
				if(empty($password)){
					$data_pengguna = array(
									'nama' 		=> $nama,
									'jenkel'	=> $jenkel,
									'pekerjaan'	=> $pekerjaan,
									'alamat'	=> $alamat
									);
					$this->model_pengguna->edit_pengguna($id_pengguna,$data_pengguna);
					$this->session->set_flashdata('pesan','Data berhasil diedit');
					redirect('pengguna/edit/'.$id_pengguna);
				}else{
					$data_pengguna = array(
									'nama' 		=> $nama,
									'jenkel'	=> $jenkel,
									'pekerjaan'	=> $pekerjaan,
									'alamat' 	=> $alamat,
									'password'	=> $password
									);
					$this->model_pengguna->edit_pengguna($id_pengguna,$data_pengguna);
					$this->session->set_flashdata('pesan','Data berhasil diedit');
					redirect('pengguna/edit/'.$id_pengguna);
				}
			}else{
				$query = $this->model_pengguna->cek_pengguna($email);
				if($query->num_rows()>0){
					$this->session->set_flashdata('pesan','Gagal, Email sudah digunakan oleh pengguna lain!!!');
					redirect('pengguna/edit/'.$id_pengguna);
				}else{
					if(empty($password)){
						$data_pengguna = array(
										'nama' 	=> $nama,
										'jenkel'	=> $jenkel,
										'pekerjaan'	=> $pekerjaan,
										'alamat'=> $alamat,
										'email' => $email
										);
						$this->model_pengguna->edit_pengguna($id_pengguna,$data_pengguna);
						$this->session->set_flashdata('pesan','Data berhasil diedit');
						redirect('pengguna/edit/'.$id_pengguna);
					}else{
						$data_pengguna = array(
										'nama' 		=> $nama,
										'jenkel'	=> $jenkel,
										'pekerjaan'	=> $pekerjaan,
										'alamat' 	=> $alamat,
										'email'		=> $email,
										'password'	=> $password
										);
						$this->model_pengguna->edit_pengguna($id_pengguna,$data_pengguna);
						$this->session->set_flashdata('pesan','Data berhasil diedit');
						redirect('pengguna/edit/'.$id_pengguna);
					}
				}
			}
		}
	}
	public function proses_hapus($id_pengguna){
		$this->model_pengguna->hapus_pengguna($id_pengguna);
		$this->session->set_flashdata('pesan','Data berhasil dihapus');
		redirect('pengguna');
	}
	public function detail_pengguna(){
		$id_pengguna = $this->input->post('rowid');
		$data['p'] 	 = $this->model_pengguna->periksa_pengguna($id_pengguna)->row_array();
		$this->load->view('detail_pengguna',$data);
	}
}
