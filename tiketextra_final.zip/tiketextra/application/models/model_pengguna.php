<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_pengguna extends CI_Model {
	public function pengguna(){
		return $this->db->get('pengguna');
	}
	public function cek_pengguna($email){
		return $this->db->where('email',$email)
						->get('pengguna');
	}
	public function periksa_pengguna($id_pengguna){
		return $this->db->where('id_pengguna',$id_pengguna)
						->get('pengguna');
	}
	public function tambah_pengguna($data_pengguna){
		return $this->db->insert('pengguna',$data_pengguna);
	}
	public function edit_pengguna($id_pengguna,$data_pengguna){
		return $this->db->where('id_pengguna',$id_pengguna)
						->update('pengguna',$data_pengguna);
	}
	public function hapus_pengguna($id_pengguna){
		return $this->db->where('id_pengguna',$id_pengguna)
						->delete('pengguna');
	}
}