<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_login extends CI_Model {
	public function cek_login($email,$password){
		return $this->db->where('email',$email)
						->where('password',$password)
						->get('pengguna');
	}
}