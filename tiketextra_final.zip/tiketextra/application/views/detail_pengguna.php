<div class="row">
<div class="col-sm-3">
    <h5>Nama</h5>
  </div>                
  <div class="col-sm-6">
    <input type="text" value="<?php echo$p['nama'] ?>" class="form-control" disabled="">
  </div>                
</div>
<div class="row">
  <div class="col-sm-3">
    <h5>Jenis Kelamin</h5>
  </div>                
  <div class="col-sm-6">
  	<?php 
  	if($p['jenkel']=='L'){
  		$jenkel='Laki-Laki';
  	}else{
  		$jenkel='Perempuan';
  	}
  	?>
    <input type="text" value="<?php echo$jenkel ?>" class="form-control" disabled="">
  </div>                
</div>
<div class="row">
  <div class="col-sm-3">
    <h5>Pekerjaan</h5>
  </div>                
  <div class="col-sm-6">
    <input type="text" value="<?php echo$p['pekerjaan'] ?>" class="form-control" disabled="">
  </div>                
</div>
<div class="row">
  <div class="col-sm-3">
    <h5>Alamat</h5>
  </div>                
  <div class="col-sm-6">
    <input type="text" value="<?php echo$p['alamat'] ?>" class="form-control" disabled="">
  </div>                
</div>
<div class="row">
  <div class="col-sm-3">
    <h5>Email</h5>
  </div>                
  <div class="col-sm-6">
    <input type="text" value="<?php echo$p['email'] ?>" class="form-control" disabled="">
  </div>                
</div>