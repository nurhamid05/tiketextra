<!DOCTYPE html>
<html>
<head>
  <title>TiketExtra</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/style_sendiri.css' ?>">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron">
  <div class="container text-center" style="visibility: hidden;">
    <h1>TiketExtra</h1>      
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="<?php echo base_url() ?>">TIKET EXTRA</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="<?php echo base_url() ?>"><span class="fa fa-home"></span> Beranda</a></li>
        <li class="active"><a href=<?php echo base_url().'pengguna' ?>><span class="fa fa-users"></span> Pengguna</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php 
        if($this->session->userdata('email')==''){

        }else{
        ?>
        <li><a href=<?php echo base_url().'dashboard/logout' ?>><span class="fa fa-sign-out"></span> Logout</a></li>
        <?php
        }
        ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container text-center">    
  <div class="row">
    <div class="col-sm-12">
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-primary text-left">
            <div class="panel-body table-responsive">
              <a href="<?php echo base_url().'pengguna/tambah' ?>"><button class="btn btn-sm btn-success">Tambah Pengguna</button></a>
              <h5 align="center" style="color: red"><?php echo $this->session->flashdata('pesan'); ?></h5>
              <div class="">
        			<table id="example" class="table table-striped table-bordered table-hover" width="100%" cellspacing="0">
                <thead>
        				<tr>
        					<th>Nama</th>
        					<th>Jenis Kelamin</th>
        					<th>Email</th>
        					<th>Aksi</th>
        				</tr>
                </thead>
                <tbody>
        				<?php 
        				foreach ($pengguna as $p) {
                if($p->jenkel=='L'){
                  $jenkel = 'Laki-Laki';
                }else{
                  $jenkel = 'Perempuan';
                }
        				echo"
        				<tr>
        					<td>".$p->nama."</td>
        					<td>".$jenkel."</td>
        					<td>".$p->email."</td>
        					<td>
                  <a href='#' data-toggle='modal' data-target='#detail_pengguna' data-id='".$p->id_pengguna."'><span class='fa fa-eye' title='Detail Data'> Detail</span></a> |
                  <a href=".base_url().'pengguna/edit/'.$p->id_pengguna."><span class='fa fa-edit' title='Edit Data'> Edit</span></a> | <a href=".'javascript:void(0)'." onclick=".'hapus('.$p->id_pengguna.')'."><span class='fa fa-trash' title='Hapus Data'> Hapus</span></a></td>
        				</tr>
        				";
        				}
        				?>
                </tbody>
        			</table>
              </div>
            </div>
          </div>
        </div>
      </div>
    
    </div>

  </div>
</div>
<footer class="container-fluid text-center">
  <div class="row">
    <div class="clearfix"></div>
    <div class="col-sm-12">
      <br>
      <p>&copy; <?php echo date('Y') ?> TiketExtra</p>
    </div>
  </div>
</footer>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
	var url="<?php echo base_url(); ?>";
	function hapus(id){
		var r = confirm("Yakin ingin menghapus data.?")
		if(r==true)
			window.location = url+"pengguna/proses_hapus/"+id;
		else
			return false;			
	}
</script>
<script>
  $(function () {
    $('#example').DataTable({
      "language": {
            "lengthMenu": "Tampilkan _MENU_ Data",
            "zeroRecords": "Data tidak ditemukan",
            "info": "Tampilkan halaman _PAGE_ dari _PAGES_",
            "infoEmpty": "Data tidak ditemukan",
            "infoFiltered": "(Dari _MAX_ Data)"
        }
    });
    $('#example1').DataTable({
      "language": {
            "lengthMenu": "Tampilkan _MENU_ Data",
            "zeroRecords": "Data tidak ditemukan",
            "info": "Tampilkan halaman _PAGE_ dari _PAGES_",
            "infoEmpty": "Data tidak ditemukan",
            "infoFiltered": "(Dari _MAX_ Data)"
        }
    });
  });
</script>

<div class="modal" id="detail_pengguna" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title custom_align" id="Heading">Detail Pengguna</h4>
            </div>
            <div class="modal-body hasil">
                
            </div>
            <div class="modal-footer ">
                <button class="btn btn-danger btn-sm" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $('#detail_pengguna').on('show.bs.modal',function(e){
      var rowid = $(e.relatedTarget).data('id');
      $.ajax({
        type : 'post',
        url : 'pengguna/detail_pengguna',
        data : 'rowid='+ rowid,
        success : function(data){
          $('.hasil').html(data);
        }
      });
    });
  });
</script>

</body>
</html>