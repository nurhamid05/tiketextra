<!DOCTYPE html>
<html>
<head>
  <title>TiketExtra</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    .dropdown{
      cursor: pointer;
    }
    .dropdown-menu{
      left: 200px;
    }
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    .navbar-inverse{
      background-color: #337ab7;
      border-color: #337ab7;
    }
    .navbar-inverse .navbar-brand{
      color: #000;
    }
    .navbar-inverse .navbar-nav>li>a{
      color: #000;
    }
     .jumbotron {
      margin-bottom: 0;
    }
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>


<div class="container text-center">    
  <div class="row">
    <div class="col-sm-3">
      <div class="row">
        <div class="col-sm-12">
          
        </div>
      </div>
    </div>
    <div class="col-sm-6">
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-primary text-left">
            <div class="panel-body" style="min-height: 200px">
              <img src="<?php echo base_url().'assets/img/logo.jpg' ?>"	 class="img-responsive" style="width: 523px;height: 200px">
            </div>
          </div>
          <div class="panel panel-primary">
            <div class="panel-heading" align="left">Login</div>
            <div class="panel-body">
              <div class="row">
                <span style="color: red"><?php echo $this->session->flashdata('pesan'); ?></span>
                <br>
				        <?php echo form_open('dashboard/login_cek'); ?>
                <div class="col-lg-6">
                  <div class="form-group">
                    <label >Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Email">
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-group">
                    <label >Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                  </div>
                </div>
                <div class="col-lg-12">
                <div class="form-group">
                  <input type='submit' class="btn btn-sm btn-success" value="Login">
                  <a href=<?php echo base_url().'register' ?>><input type='button' class="btn btn-sm btn-primary" value="Register"></a>
                </div>
                </div>
                <?php echo form_close(); ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    
    </div>
  </div>
</div>
</body>
</html>