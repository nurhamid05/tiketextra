<!DOCTYPE html>
<html>
<head>
  <title>TiketExtra</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    h5{
    	text-align: left;
    }
  </style>
</head>
<body>


<div class="container text-center">    
  <div class="row">
    <div class="col-sm-3">
      <div class="row">
        <div class="col-sm-12">
          
        </div>
      </div>
    </div>
    <div class="col-sm-6">
      <div class="row">
        <div class="col-sm-12">
        <br>
          <div class="panel panel-primary">
            <div class="panel-heading" align="left">Register</div>
            <div class="panel-body">
            	<div class="row">
              		<div class="col-sm-3">
					  <h5></h5>
					</div>                
					<div class="col-sm-9">
					  <h5 style="color: red"><?php echo $this->session->flashdata('pesan') ?></h5>
					</div>                
					</div>
					<?php echo form_open('register/register_cek'); ?>
					<div class="row">
					<div class="col-sm-4">
					  <h5>Nama</h5>
					</div>                
					<div class="col-sm-6">
					  <input type="text" name="nama" placeholder="Nama" class="form-control" required=''>
					</div>                
					</div>
					<div class="row">
					<div class="col-sm-4">
					  <h5>Jenis Kelamin</h5>
					</div>                
					<div class="col-sm-6">
					  	<select class="form-control" name="jenkel" required="">
					  		<option value="">-Pilih Jenis Kelamin-</option>
					  	    <option value="L">Laki-Laki</option>
					    	<option value="P">Perempuan</option>
					  	</select>
					</div>                
					</div>
					<div class="row">
					<div class="col-sm-4">
					  <h5>Pekerjaan</h5>
					</div>                
					<div class="col-sm-6">
					  <input type="text" name="pekerjaan" placeholder="Pekerjaan" class="form-control" required=''>
					</div>                
					</div>
					<div class="row">
					<div class="col-sm-4">
					  <h5>Alamat</h5>
					</div>                
					<div class="col-sm-6">
					  <input type="text" name="alamat" placeholder="Alamat" class="form-control" required=''>
					</div>                
					</div>
					<div class="row">
					<div class="col-sm-4">
					  <h5>Email</h5>
					</div>                
					<div class="col-sm-6">
					  <input type="email" name="email" placeholder="Email" class="form-control" required=''>
					</div>                
					</div>
					<div class="row">
					<div class="col-sm-4">
					  <h5>Password</h5>
					</div>                
					<div class="col-sm-6">
					  <input type="password" name="password" placeholder="Password" class="form-control" required="">
					</div>                
					</div>
					<div class="row">
					<div class="col-sm-3">
					</div>                
					<div class="col-sm-6">
					  <br>
					  <button type="submit" class="btn btn-sm btn-success">Register</button>
					  <a href="<?php echo base_url().'login' ?>"><button type="button" class="btn btn-sm btn-danger">Batal</button></a>
					</div>                
					</div>
					<?php echo form_close(); ?>
            	</div>
            </div>
          </div>
        </div>
      </div>
    
    </div>
  </div>
</div>
</body>
</html>