<!DOCTYPE html>
<html>
<head>
  <title>TiketExtra</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/style_sendiri.css' ?>">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron">
  <div class="container text-center" style="visibility: hidden;">
    <h1>TiketExtra</h1>      
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="<?php echo base_url() ?>">TIKET EXTRA</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="<?php echo base_url() ?>"><span class="fa fa-home"></span> Beranda</a></li>
        <li class="active"><a href=<?php echo base_url().'pengguna' ?>><span class="fa fa-users"></span> Pengguna</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php 
        if($this->session->userdata('email')==''){

        }else{
        ?>
        <li><a href=<?php echo base_url().'dashboard/logout' ?>><span class="fa fa-sign-out"></span> Logout</a></li>
        <?php
        }
        ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container text-center">    
  <div class="row">
    <div class="col-sm-12">
    
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-primary text-left">
            <div class="panel-body">
            <div class="row">
            <div class="col-sm-2">
              <h5></h5>
            </div>                
            <div class="col-sm-4">
              <h5 style="color: red"><?php echo $this->session->flashdata('pesan') ?></h5>
            </div>                
            </div>
      			<?php echo form_open('pengguna/proses_tambah/')?>
            <div class="row">
            <div class="col-sm-2">
              <h5>Nama</h5>
            </div>                
            <div class="col-sm-4">
              <input type="text" name="nama" placeholder="Nama" class="form-control" required=''>
            </div>                
            </div>
            <div class="row">
            <div class="col-sm-2">
              <h5>Jenis Kelamin</h5>
            </div>                
            <div class="col-sm-4">
                <select class="form-control" name="jenkel" required="">
                  <option value="">-Pilih Jenis Kelamin-</option>
                    <option value="L">Laki-Laki</option>
                  <option value="P">Perempuan</option>
                </select>
            </div>                
            </div>
            <div class="row">
            <div class="col-sm-2">
              <h5>Pekerjaan</h5>
            </div>                
            <div class="col-sm-4">
              <input type="text" name="pekerjaan" placeholder="Pekerjaan" class="form-control" required=''>
            </div>                
            </div>
            <div class="row">
            <div class="col-sm-2">
              <h5>Alamat</h5>
            </div>                
            <div class="col-sm-4">
              <input type="text" name="alamat" placeholder="Alamat" class="form-control" required=''>
            </div>                
            </div>
            <div class="row">
            <div class="col-sm-2">
              <h5>Email</h5>
            </div>                
            <div class="col-sm-4">
              <input type="email" name="email" placeholder="Email" class="form-control" required=''>
            </div>                
            </div>
            <div class="row">
            <div class="col-sm-2">
              <h5>Password</h5>
            </div>                
            <div class="col-sm-4">
              <input type="password" name="password" placeholder="Password" class="form-control" required="">
            </div>                
            </div>
            <div class="row">
            <div class="col-sm-2">
            </div>                
            <div class="col-sm-4">
              <br>
              <button type="submit" class="btn btn-sm btn-success">Tambah</button>
              <a href="<?php echo base_url().'pengguna' ?>"><button type="button" class="btn btn-sm btn-danger">Batal</button></a>
            </div>                
            </div>
      			<?php echo form_close();?>
            </div>
          </div>
        </div>
      </div>
    
    </div>
    
  </div>
</div>
<footer class="container-fluid text-center">
  <div class="row">
    <div class="clearfix"></div>
    <div class="col-sm-12">
      <br>
      <p>&copy; <?php echo date('Y') ?> TiketExtra</p>
    </div>
  </div>
</footer>
</body>
</html>
